from django.apps import AppConfig


class BasesConfig(AppConfig):
    name = 'bases'
