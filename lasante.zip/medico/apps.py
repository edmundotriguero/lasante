from django.apps import AppConfig


class MedicoConfig(AppConfig):
    name = 'medico'
