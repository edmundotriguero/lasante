from django.apps import AppConfig


class CajasConfig(AppConfig):
    name = 'cajas'
