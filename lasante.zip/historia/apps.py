from django.apps import AppConfig


class HistoriaConfig(AppConfig):
    name = 'historia'
