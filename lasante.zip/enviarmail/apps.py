from django.apps import AppConfig


class EnviarmailConfig(AppConfig):
    name = 'enviarmail'
