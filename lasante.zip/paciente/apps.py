from django.apps import AppConfig


class PacienteConfig(AppConfig):
    name = 'paciente'
